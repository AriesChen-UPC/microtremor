# TODO

> Joseph P. Vantassel, The University of Texas at Austin

## Before next release

-   Statistics workflow.
-   Trimming a record (-0.5 to 1) between (0.1 and 0.95) gives ValueError.
-   Make df a figurative rather than literal attribute.
-   Waveform normalization bnz 0.5m.
-   Add test case for from_max from waterplant.
-   Corr shift test failing.
-   Change `single` to `nostacking`.
-   _delay in ActiveTimeSeries.

## Long term

-   Slow down on Michael's machine.
-   Take noise from the end of the record.
