.. masw:

masw
=======

.. automodule:: swprocess.masw
   :members:
   :undoc-members:
   :show-inheritance:
