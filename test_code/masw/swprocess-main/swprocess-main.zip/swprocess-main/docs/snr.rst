.. snr:

snr
===

.. automodule:: swprocess.snr
   :members:
   :undoc-members:
   :show-inheritance:
