.. peaks:

peaks
=====

.. automodule:: swprocess.peaks
   :members:
   :undoc-members:
   :show-inheritance:
