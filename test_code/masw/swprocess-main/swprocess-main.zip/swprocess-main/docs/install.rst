.. _install:

Installation
============

``pip install swprocess`` or ``pip install swprocess --upgrade``

``pip`` will handle the rest!
