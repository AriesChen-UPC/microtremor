.. _api:

API Reference
=============

.. toctree::
   :maxdepth: 2

   activetimeseries
   array1d
   masw
   maswworkflows
   peaks
   peakssuite
   regex
   register
   sensor1c
   snr
   source
   spaccurve
   spaccurvesuite
   utils
   wavefieldtransforms