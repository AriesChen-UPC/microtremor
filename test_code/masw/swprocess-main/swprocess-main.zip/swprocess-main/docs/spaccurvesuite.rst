.. SpacCurveSuite:

spaccurvesuite
==============

.. automodule:: swprocess.spaccurvesuite
   :members:
   :undoc-members:
   :show-inheritance:
