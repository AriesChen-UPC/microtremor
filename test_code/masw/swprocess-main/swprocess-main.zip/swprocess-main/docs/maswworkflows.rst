.. maswworkflows:

maswworkflows
=============

.. automodule:: swprocess.maswworkflows
   :members:
   :undoc-members:
   :show-inheritance:
