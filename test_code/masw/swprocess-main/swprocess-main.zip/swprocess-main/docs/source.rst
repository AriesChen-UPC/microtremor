.. source:

source
======

.. automodule:: swprocess.source
   :members:
   :undoc-members:
   :show-inheritance:
