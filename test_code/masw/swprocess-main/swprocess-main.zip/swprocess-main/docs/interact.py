.. interact:

Interact
=======

.. automodule:: swprocess.interact
   :members:
   :undoc-members:
   :show-inheritance:
