.. register:

register
========

.. automodule:: swprocess.register
   :members:
   :undoc-members:
   :show-inheritance:
