.. array1d:

array1d
=======

.. automodule:: swprocess.array1d
   :members:
   :undoc-members:
   :show-inheritance:
