.. activetimeseries:

activetimeseries
================

.. automodule:: swprocess.activetimeseries
   :members:
   :undoc-members:
   :show-inheritance:
