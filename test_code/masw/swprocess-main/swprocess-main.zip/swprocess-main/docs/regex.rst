.. regex:

regex
=====

.. automodule:: swprocess.regex
   :members:
   :undoc-members:
   :show-inheritance:
