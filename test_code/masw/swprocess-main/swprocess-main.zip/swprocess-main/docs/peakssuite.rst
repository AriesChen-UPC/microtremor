.. PeaksSuite:

peakssuite
==========

.. automodule:: swprocess.peakssuite
   :members:
   :undoc-members:
   :show-inheritance:
