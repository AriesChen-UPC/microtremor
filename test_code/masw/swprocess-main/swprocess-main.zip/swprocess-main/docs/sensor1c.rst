.. sensor1c:

sensor1c
========

.. automodule:: swprocess.sensor1c
   :members:
   :undoc-members:
   :show-inheritance:
