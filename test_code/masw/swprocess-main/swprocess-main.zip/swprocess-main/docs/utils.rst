.. utils:

utils
=====

.. automodule:: swprocess.utils
   :members:
   :undoc-members:
   :show-inheritance:
