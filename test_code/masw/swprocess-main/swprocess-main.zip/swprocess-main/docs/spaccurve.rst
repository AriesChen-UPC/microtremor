.. SpacCurve:

spaccurve
==========

.. automodule:: swprocess.spaccurve
   :members:
   :undoc-members:
   :show-inheritance:
